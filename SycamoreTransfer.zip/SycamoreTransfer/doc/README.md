# Sycamore Transfer

- **Drew Charters** (charters@usc.edu)
- **Lauren Hampson** (lhampson@usc.edu)
- **Ishan Shah** (ishans@usc.edu)
- **Zane Durante** (durante@usc.edu)
- **Kousheyo Kundu** (kousheyk@usc.edu)
- **Tomas Acin-Chediex** (acinched@usc.edu)

## Overview
As a whole, the project works as intended. If all is set up
correctly as explained in the Document Deployment, then upon
running the program, the user should experience all of the
intended functionality. That being said, there are a couple
of nuances present, such as the issue with certain images being
corrupted whenever downloaded for style transfer or the random
failure of a servlet connection from time to time. Also, the user
may experience the meaningless time stamps on the global feed.
Nonetheless, these are all minor issues and the program as a whole
continues to work almost perfectly fine.