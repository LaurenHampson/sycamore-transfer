import java.util.ArrayList;

public class PhotoStream {
	public ArrayList<PhotoPair> streamArray;
}
