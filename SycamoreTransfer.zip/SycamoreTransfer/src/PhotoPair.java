
public class PhotoPair {
	public int imageID;
	public String user;
	public String originalPhotoPath;
	public String newPhotoPath;
	public int numLikes;
	public boolean likedByCurrUser;
	public String timediff;
}
