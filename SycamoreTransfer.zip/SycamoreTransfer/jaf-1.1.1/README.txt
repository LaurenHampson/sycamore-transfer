	  **JAVABEANS(tm) ACTIVATION FRAMEWORK 1.1.1 RELEASE**

Thank you for downloading the release of the JavaBeans(tm) Activation
Framework! We hope you find it useful.  Included in this release are
the following files and directories:

README.txt     : This file!

RELNOTES.txt   : The release notes for this release including,
                 installation instructions, system requirements, 
                 known bugs, and open issues.

LICENSE.txt    : The license covering this software.

activation.jar : This JAR file contains the classes that
                 make up JavaBeans(tm) Activation Framework.

demos          : This directory contains some simple *unsupported*
                 demos that make use of some of the JAF's features.

docs           : This directory contains the Javadoc API descriptions
                 for the public classes in the JAF.

If you encounter any problems please contact us at:

  activation-comments@sun.com
